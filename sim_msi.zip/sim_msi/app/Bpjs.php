<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bpjs extends Model
{
    protected $guarded = [];
    
}
