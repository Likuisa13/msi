<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class obat_masuk extends Model
{
    //
    protected $guarded = [];
    
}
