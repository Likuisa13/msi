<?php

namespace App\Imports;

use App\Resign;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class ResignImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Resign([
            'id_karyawan' => $row['no_id'],
            'tgl_resign' => $row['tgl_resign'],
            'jenis_resign' => $row['jenis_resign'],
            'keterangan' => $row['keterangan'],
        ]);
    }
    public function headingRow(): int
    {
        return 4;
    }
}
