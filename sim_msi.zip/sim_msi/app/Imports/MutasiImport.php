<?php

namespace App\Imports;

use App\Mutasi;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class MutasiImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Mutasi([
            'id_karyawan' => $row['no_id'],
            'bagian_asal' => $row['bagian_asal'],
            'seksi_asal' => $row['seksi_asal'],
            'posisi_asal' => $row['posisi_asal'],
            'bagian_tujuan' => $row['bagian_tujuan'],
            'seksi_tujuan' => $row['seksi_tujuan'],
            'posisi_tujuan' => $row['posisi_tujuan'],
            'tgl_mutasi' => $row['tgl_mutasi'],
        ]);
    }
    public function headingRow(): int
    {
        return 4;
    }
}
