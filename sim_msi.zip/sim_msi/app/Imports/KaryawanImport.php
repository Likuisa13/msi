<?php

namespace App\Imports;

use App\Karyawan; 
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class KaryawanImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Karyawan([
            'id_karyawan' => $row['no_id'],
            'nama_karyawan' => $row['nama'],
            'tgl_masuk' => date('Y-m-d', strtotime($row['tgl_masuk'])),
            'bagian' => $row['bagian'],
            'seksi' => $row['seksi'],
            'status_peg' => $row['status_peg'],
            'posisi' => $row['jabatan'],
            'no_k1' => $row['no_kontrak1'],
            'k1_awal' => date('Y-m-d', strtotime($row['awal_kontrak_1'])),
            'k1_akhir' => date('Y-m-d', strtotime($row['akhir_kontrak_1'])),
            'no_k2' => $row['no_kontrak2'],
            'k2_awal' => date('Y-m-d', strtotime($row['awal_kontrak_2'])),
            'k2_akhir' => date('Y-m-d', strtotime($row['akhir_kontrak_2'])),
            'no_ktp' => $row['no_ktp'],
            'pendidikan' => $row['pendidikan'],
            // 'no_bpjs_kis' => $row['no_bpjs_kis'],
            // 'no_bpjs_kerja' => $row['no_bpjs_ket'],
            'tempat_lahir' => $row['tempat_lahir'],
            'tgl_lahir' => date('Y-m-d', strtotime($row['tgl_lahir'])),
            'jk' => $row['l_p'],
            'status' => $row['status'],
            'anak' => $row['jml_anak'],
            'pasangan'=> $row['suami_istri'],
            'alamat' => $row['alamat'],
            'telp' => $row['no_telp'],
            'hp' => $row['no_telp_lain'],
            'email' => $row['email'],
            'agama' => $row['agama']
        ]);
    }
    public function headingRow(): int
    {
        return 4;
    }
}
