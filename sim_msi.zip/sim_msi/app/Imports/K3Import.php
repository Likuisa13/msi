<?php

namespace App\Imports;

use App\K3;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class K3Import implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new K3([
            'id_karyawan' => $row['no_id'],
            'waktu' => $row['waktu'],
            'akibat' => $row['akibat'],
            'cidera' => $row['cidera'],
            'sumber' => $row['sumber'],
            'tipe' => $row['tipe'],
            'bagian_tubuh' => $row['bagian_tubuh_cidera'],
            'kerugian' => $row['perkiraan_kerugian'],
            'penyebab' => $row['penyebab_kecelakaan'],
        ]);
    }
    public function headingRow(): int
    {
        return 4;
    }
} 
