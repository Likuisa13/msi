<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ObatMskExport;
use App\Exports\ObatExport;
use App\Exports\ObatKeluarExport;
// use App\Imports\ResignImport;
use DB;
use PDF;

class ObatController extends Controller
{
	public function show()
	{
		$obat = DB::table('obats')->get();
		$obat_masuk = DB::table('obat_masuks')
		->select(DB::raw('obat_masuks.*, obats.nama_obat'))
		->join('obats', 'obat_masuks.id_obat', '=', 'obats.id_obat')
		->get();
		return view('admin.obat',compact('obat'));
	}

	public function showMasuk()
	{
		$obat = DB::table('obats')
		// ->where('stok', '>', 0)
		->get();
		$obat_masuk = DB::table('obat_masuks')
		->select(DB::raw('obat_masuks.*, obats.nama_obat,obats.satuan'))
		->join('obats', 'obat_masuks.id_obat', '=', 'obats.id_obat')
		->get();
		return view('admin.obat_masuk',compact('obat_masuk','obat'));
	}

	public function showKeluar()
	{
		$obat = DB::table('obats')
		->where('stok', '>', 0)
		->get();

		$karyawan = DB::table('karyawans')->get();

		$obat_keluar = DB::table('obat_keluars')
		->select(DB::raw('obat_keluars.*, obats.nama_obat,obats.satuan, karyawans.id_karyawan, karyawans.nama_karyawan'))
		->join('obats', 'obat_keluars.id_obat', '=', 'obats.id_obat')
		->join('karyawans', 'obat_keluars.id_karyawan', '=', 'karyawans.id_karyawan')
		->get();
		return view('admin.obat_keluar',compact('obat_keluar','obat','karyawan'));
	}

	public function aksi(Request $request)
	{ 
		// dd($request->get('aksi'));
		if ($request->get('aksi') == "save") {
			DB::table('obats')->insert([
				'nama_obat' => $request->get('nama_obat'),
				'jenis_obat' => $request->get('jenis_obat'),
				'satuan' => $request->get('satuan'),
			]);
		}
		else{
			// dd($request->get('id_masuk'));
			DB::table('obats')
			->where('id_obat',$request->get('id_obat'))
			->update([
				'nama_obat' => $request->get('nama_obat'),
				'jenis_obat' => $request->get('jenis_obat'),
				'satuan' => $request->get('satuan'),
			]);
		}
		if ($request->get('sumber') == "masuk") {
			return redirect('/admin/obat/masuk');
		}
		elseif ($request->get('sumber') == "keluar") {
			return redirect('/admin/obat/keluar');
		}
		else{
			return redirect('/admin/obat');
		}
	}


	public function aksiMasuk(Request $request)
	{ 
		// dd($request->get('aksi'));
		if ($request->get('aksi') == "save") {
			DB::table('obat_masuks')->insert([
				'id_obat' => $request->get('id_obat'),
				'tgl_masuk' => $request->get('tgl_masuk'),
				'sumber' => $request->get('sumber'),
				'jumlah' => $request->get('jumlah'),
			]);
			DB::table('obats')
			->where('id_obat',$request->get('id_obat'))
			->increment('stok', $request->get('jumlah'));
		}
		else{
			// dd($request->get('id_masuk'));
			DB::table('obat_masuks')
			->where('id_masuk',$request->get('id_masuk'))
			->update([
				'id_obat' => $request->get('id_obat'),
				'tgl_masuk' => $request->get('tgl_masuk'),
				'sumber' => $request->get('sumber'),
				'jumlah' => $request->get('jumlah'),
			]);
			$jml = (int)$request->get('jumlah') - (int)$request->get('jumlah1');
			DB::table('obats')
			->where('id_obat',$request->get('id_obat'))
			->increment('stok', $jml);
		}
		// dd($jml);
		return redirect('/admin/obat/masuk');
	}

	public function aksiKeluar(Request $request)
	{ 
		// dd($request->get('aksi'));
		if ($request->get('aksi') == "save") {
			DB::table('obat_keluars')->insert([
				'id_obat' => $request->get('id_obat'),
				'tgl_keluar' => $request->get('tgl_keluar'),
				'id_karyawan' => $request->get('id_karyawan'),
				'jumlah' => $request->get('jumlah'),
				'keluhan' => $request->get('keluhan'),
			]);
			DB::table('obats')
			->where('id_obat',$request->get('id_obat'))
			->decrement('stok', $request->get('jumlah'));
		}
		else{
			// dd($request->get('id_masuk'));
			DB::table('obat_keluars')
			->where('id_keluar',$request->get('id_keluar'))
			->update([
				'id_obat' => $request->get('id_obat'),
				'tgl_keluar' => $request->get('tgl_keluar'),
				'id_karyawan' => $request->get('id_karyawan'),
				'jumlah' => $request->get('jumlah'),
				'keluhan' => $request->get('keluhan'),
			]);
			$jml = (int)$request->get('jumlah1') - (int)$request->get('jumlah');
			DB::table('obats')
			->where('id_obat',$request->get('id_obat'))
			->decrement('stok', $jml);
		}
		// dd($jml);
		return redirect('/admin/obat/keluar');
	}

	public function del(Request $request)
	{
		$id = $request->get('id');
		DB::table('obats')->where('id_obat',$id)->delete();
        //dd($request->get('id'));
		return redirect('/admin/obat');   
	}

	public function delMasuk(Request $request)
	{
		$id = $request->get('id');
		DB::table('obat_masuks')->where('id_masuk',$id)->delete();
		DB::table('obats')
			->where('id_obat',$request->get('id_obatku'))
			->decrement('stok', (int)$request->get('jumlah_obat'));
        //	dd($request->get('jumlah_obat'));
		return redirect('/admin/obat/masuk');   
	}

	public function delKeluar(Request $request)
	{
		$id = $request->get('id');
		DB::table('obat_keluars')->where('id_keluar',$id)->delete();
		DB::table('obats')
			->where('id_obat',$request->get('id_obatku'))
			->increment('stok', (int)$request->get('jumlah_obat'));
        //dd($request->get('id'));
		return redirect('/admin/obat/keluar');   
	}

	public function export(Request $request) 
	{
		return Excel::download(new ObatExport, 'stok obat.xlsx');
	}

	public function exportMasuk(Request $request) 
	{
		$excel = new ObatMskExport;
		$excel->tgl1 = $request->get('tgl1');
		$excel->tgl2 = $request->get('tgl2');
		return Excel::download( $excel, 'obat masuk.xlsx');
	}

	public function exportKeluar(Request $request) 
	{
		$excel = new ObatKeluarExport;
		$excel->tgl1 = $request->get('tgl1');
		$excel->tgl2 = $request->get('tgl2');
		return Excel::download( $excel, 'obat keluar.xlsx');
	}
}
