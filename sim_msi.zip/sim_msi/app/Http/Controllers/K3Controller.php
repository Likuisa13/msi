<?php

namespace App\Http\Controllers;

use Maatwebsite\Excel\Facades\Excel;
use App\Exports\K3Export;
use App\Imports\K3Import;
use DB;
use PDF;
use Illuminate\Http\Request;

class K3Controller extends Controller
{
	public function show()
	{
		$k3 = DB::table('k3s')
		->select(DB::raw('k3s.*, karyawans.nama_karyawan'))
		->join('karyawans', 'k3s.id_karyawan', '=', 'karyawans.id_karyawan')
		->get();
         // dd($karyawan);
		return view('admin.k3',compact('k3'));
	}

	public function aksi(Request $request)
	{ 
		// dd($request->get('aksi'));
		if ($request->get('aksi') == "save") {
			DB::table('k3s')->insert([
				'waktu' => $request->get('waktu'),
				'id_karyawan' => $request->get('id_karyawan'),
				'akibat' => $request->get('akibat'),
				'cidera' => $request->get('cidera'),
				'sumber' => $request->get('sumber'),
				'tipe' => $request->get('tipe'),
				'bagian_tubuh' => $request->get('bagian_tubuh'),
				'kerugian' => $request->get('kerugian'),
				'penyebab' => $request->get('penyebab'),
			]);
		}
		else{
			DB::table('k3s')
			->where('id_k3',$request->get('id_k3'))
			->update([
				'waktu' => $request->get('waktu'),
				'id_karyawan' => $request->get('id_karyawan'),
				'akibat' => $request->get('akibat'),
				'cidera' => $request->get('cidera'),
				'sumber' => $request->get('sumber'),
				'tipe' => $request->get('tipe'),
				'bagian_tubuh' => $request->get('bagian_tubuh'),
				'kerugian' => $request->get('kerugian'),
				'penyebab' => $request->get('penyebab'),
			]);
		}
		return redirect('/admin/k3');
	}

	public function del(Request $request)
	{
		$id = $request->get('id');
		DB::table('k3s')->where('id_k3',$id)->delete();
        //dd($request->get('id'));
		return redirect('/admin/k3');   
	}

	public function export(Request $request) 
	{
		$excel = new K3Export;
		$excel->tgl1 = $request->get('tgl1');
		$excel->tgl2 = $request->get('tgl2');
		return Excel::download( $excel, 'kecelakaan.xlsx');
	}

	public function storeData(Request $request)
	{
        //VALIDASI
		$this->validate($request, [
			'file' => 'required|mimes:xls,xlsx'
		]);

		if ($request->hasFile('file')) {
            $file = $request->file('file'); //GET FILE
            Excel::import(new K3Import, $file); //IMPORT FILE 
            return redirect()->back()->with(['success' => 'Upload success']);
        }  
        return redirect()->back()->with(['error' => 'Please choose file before']);
    }


}
