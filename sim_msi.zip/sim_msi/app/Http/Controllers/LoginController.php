<?php
use App\Admin;
use App\User;
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoginController extends Controller
{
	public function index()
	{
		return view('login');    
	}

	public function login(Request $request)
	{
		$admin = Admin::where('username',$request->username)->first();
		$user = User::where('username',$request->username)->first();
        // dd(!$admin);
        // dd(Hash::make($request->password));
		if($admin && Hash::check($request->password, $admin->password)){

			Auth::guard('admin')->LoginUsingId($admin->id);

			Session::put('pengguna','admin');
			Session::put('admin',$admin->id);

			return redirect('/admin/home');

		}else if($user && Hash::check($request->password, $user->password)){
			Auth::guard('user')->LoginUsingId($user->id);

			Session::put('pengguna','user');
			Session::put('user',$user->id);

			return redirect('/admin/k3');
		}else{
			return redirect()->route('login');
		} 
	}

	public function logout()
	{
		if(Auth::guard('admin')->check()){
			Auth::guard('admin')->logout();

		}else{
			Auth::guard('user')->logout();

		}

		return redirect()->route('login');
	}
}
