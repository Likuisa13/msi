<?php

namespace App\Http\Controllers; 

use Illuminate\Http\Request;
use App\Exports\BpjsExport;
use App\Imports\BpjsImport;
use Maatwebsite\Excel\Facades\Excel;
use DB;
use PDF;
class BpjsController extends Controller
{
	public function show()
	{
		$bpjs = DB::table('bpjs')
		->select(DB::raw('bpjs.id_bpjs, karyawans.id_karyawan, karyawans.nama_karyawan, bpjs.no_bpjs_kis, bpjs.status_bpjs, bpjs.no_bpjs_ket'))
		->join('karyawans', 'bpjs.id_karyawan', '=', 'karyawans.id_karyawan')
		->get();
        // dd($karyawan);
		return view('admin.bpjs',compact('bpjs'));
	}

	public function aksiBpjs(Request $request)
	{ 
		if ($request->get('aksi') == "save") {
			DB::table('bpjs')->insert([
				'id_karyawan' => $request->get('id_karyawan'),
				'no_bpjs_kis' => $request->get('no_bpjs_kis'),
				'status_bpjs' => $request->get('status_bpjs'),
				'no_bpjs_ket' => $request->get('no_bpjs_kerja'),
			]);
		}
		else{
			DB::table('bpjs')
			->where('id_bpjs',$request->get('id_bpjs'))
			->update([
				'id_karyawan' => $request->get('id_karyawan'),
				'no_bpjs_kis' => $request->get('no_bpjs_kis'),
				'status_bpjs' => $request->get('status_bpjs'),
				'no_bpjs_ket' => $request->get('no_bpjs_kerja'),
			]);
		}
		return redirect('/admin/bpjs');
	}

	public function del(Request $request)
	{
		$id = $request->get('id');
		DB::table('bpjs')->where('id_bpjs',$id)->delete();
        //dd($request->get('id'));
		return redirect('/admin/bpjs');   
	}

	public function export() 
	{
		return Excel::download(new BpjsExport, 'bpjs.xlsx');
	}

	public function storeData(Request $request)
	{
        //VALIDASI
		$this->validate($request, [
			'file' => 'required|mimes:xls,xlsx'
		]);

		if ($request->hasFile('file')) {
            $file = $request->file('file'); //GET FILE
            Excel::import(new BpjsImport, $file); //IMPORT FILE 
            return redirect()->back()->with(['success' => 'Upload success']);
        }  
        return redirect()->back()->with(['error' => 'Please choose file before']);
    }

    public function cetak()
    {
    	$bpjs = DB::table('bpjs')
    	->join('karyawans', 'bpjs.id_karyawan', '=', 'karyawans.id_karyawan')
    	->get();

    	$pdf = PDF::loadview('admin.bpjs_pdf',['bpjs'=>$bpjs]);
    	// return $pdf->download('laporan-karyawan.pdf');
    	$pdf->setPaper('A4', 'portait');
    	return $pdf->stream('laporan-bpjs.pdf');
    }
}
