<?php

namespace App\Http\Controllers;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\ResignExport;
use App\Imports\ResignImport;
use Illuminate\Http\Request;
use DB;
use PDF;


class ResignController extends Controller
{
	public function show()
	{
		$resign = DB::table('resigns')
		->select(DB::raw('resigns.*, karyawans.nama_karyawan'))
		->join('karyawans', 'resigns.id_karyawan', '=', 'karyawans.id_karyawan')
		->get();
        // dd($karyawan);
		return view('admin.resign',compact('resign'));
	}

	public function aksi(Request $request)
	{ 
		// dd($request->get('aksi'));
		if ($request->get('aksi') == "save") {
			DB::table('resigns')->insert([
				'id_karyawan' => $request->get('id_karyawan'),
				'tgl_resign' => $request->get('tgl_resign'),
				'jenis_resign' => $request->get('jenis_resign'),
				'keterangan' => $request->get('keterangan'),
			]);
		}
		else{
			DB::table('resigns')
			->where('id_resign',$request->get('id_resign'))
			->update([
				'id_karyawan' => $request->get('id_karyawan'),
				'tgl_resign' => $request->get('tgl_resign'),
				'jenis_resign' => $request->get('jenis_resign'),
				'keterangan' => $request->get('keterangan'),
			]);
		}
		return redirect('/admin/resign');
	}

	public function del(Request $request)
	{
		$id = $request->get('id');
		DB::table('resigns')->where('id_resign',$id)->delete();
        //dd($request->get('id'));
		return redirect('/admin/resign');   
	}

	public function export() 
	{
		return Excel::download(new ResignExport, 'resign.xlsx');
	}

	public function storeData(Request $request)
	{
        //VALIDASI
		$this->validate($request, [
			'file' => 'required|mimes:xls,xlsx'
		]);

		if ($request->hasFile('file')) {
            $file = $request->file('file'); //GET FILE
            Excel::import(new ResignImport, $file); //IMPORT FILE 
            return redirect()->back()->with(['success' => 'Upload success']);
        }  
        return redirect()->back()->with(['error' => 'Please choose file before']);
    }

    public function cetak()
    {
    	$resign = DB::table('resigns')
		->select(DB::raw('resigns.*, karyawans.nama_karyawan'))
		->join('karyawans', 'resigns.id_karyawan', '=', 'karyawans.id_karyawan')
		->get();

    	$pdf = PDF::loadview('admin.resign_pdf',['resign'=>$resign]);
    	// return $pdf->download('laporan-karyawan.pdf');
    	$pdf->setPaper('A4', 'portait');
    	return $pdf->stream('laporan-resign.pdf');
    }
}
