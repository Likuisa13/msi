<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Exports\KaryawanExport;
use App\Imports\KaryawanImport;
use Maatwebsite\Excel\Facades\Excel;
use PDF;
use DB;

class KaryawanController extends Controller
{
	public function show($status)
	{
		$karyawan = DB::table('karyawans')->where('sts',$status)->orderBy('id_karyawan','asc')->get();

         // dd($karyawan);
		return view('admin.karyawan',compact('karyawan'));
	}

	function cek(Request $request)
	{
		$id = $request->get('id');
		$karyawan = DB::table('karyawans')
		->select(DB::raw('nama_karyawan'))
		->where('id_karyawan',$status)->first();
     // $output = '<option value="">Select '.ucfirst($dependent).'</option>';
     // foreach($data as $row)
     // {
     //  $output = $row->$nama_karyawan;
     // }
		// echo $output;
		$karyawan = json_encode($karyawan);
		echo $karyawan;
		// return view('admin.tes',compact('karyawan'));
	}

	public function add()
	{
		return view('admin.tambah_karyawan');
	}

	public function save(Request $request)
	{ 
		DB::table('karyawans')->insert([
			'id_karyawan' => $request->get('id_karyawan'),
			'nama_karyawan' => $request->get('nama_karyawan'),
			'bagian' => $request->get('bagian'),
			'tgl_masuk' => $request->get('tgl_masuk'),
			'posisi' => $request->get('posisi'),
			'seksi' => $request->get('seksi'),
			'no_k1' => $request->get('no_k1'),
			'k1_awal' => $request->get('k1_awal'),
			'k1_akhir' => $request->get('k1_akhir'),
			'no_k2' => $request->get('no_k2'),
			'k2_awal' => $request->get('k2_awal'),
			'k2_akhir' => $request->get('k2_akhir'),
			'status_peg' => $request->get('status_peg'),
			'pendidikan' => $request->get('pendidikan'),
			'no_ktp' => $request->get('no_ktp'),
			'tempat_lahir' => $request->get('tempat_lahir'),
			'tgl_lahir' => $request->get('tgl_lahir'),
			'jk' => $request->get('jk'),
			'agama' => $request->get('agama'),
			'email' => $request->get('email'),
			'status' => $request->get('status'), 
			'pasangan'=> $request->get('pasangan'),
			'anak' => $request->get('anak'),
			'telp' => $request->get('telp'),
			'hp' => $request->get('hp'),
			'alamat' => $request->get('alamat'),
			// 'no_bpjs_kis' => $request->get('no_bpjs_kis'),
			// 'no_bpjs_kerja' => $request->get('no_bpjs_kerja'),
		]);

		return redirect('/admin/karyawan/Aktif');
	}

	public function update(Request $request)
	{
		DB::table('karyawans')
		->where('id_karyawan',$request->get('idedit'))
		->update([
			'id_karyawan' => $request->get('id_karyawan'),
			'nama_karyawan' => $request->get('nama_karyawan'),
			'bagian' => $request->get('bagian'),
			'tgl_masuk' => $request->get('tgl_masuk'),
			'posisi' => $request->get('posisi'),
			'seksi' => $request->get('seksi'),
			'no_k1' => $request->get('no_k1'),
			'k1_awal' => $request->get('k1_awal'),
			'k1_akhir' => $request->get('k1_akhir'),
			'no_k2' => $request->get('no_k2'),
			'k2_awal' => $request->get('k2_awal'),
			'k2_akhir' => $request->get('k2_akhir'),
			'status_peg' => $request->get('status_peg'),
			'pendidikan' => $request->get('pendidikan'),
			'no_ktp' => $request->get('no_ktp'),
			'tempat_lahir' => $request->get('tempat_lahir'),
			'tgl_lahir' => $request->get('tgl_lahir'),
			'jk' => $request->get('jk'),
			'agama' => $request->get('agama'),
			'email' => $request->get('email'),
			'status' => $request->get('status'), 
			'pasangan'=> $request->get('pasangan'),
			'anak' => $request->get('anak'),
			'telp' => $request->get('telp'),
			'hp' => $request->get('hp'),
			'alamat' => $request->get('alamat'),
			// 'no_bpjs_kis' => $request->get('no_bpjs_kis'),
			// 'no_bpjs_kerja' => $request->get('no_bpjs_kerja'),
		]);
		// dd($request->get('idedit'));
		return redirect('/admin/karyawan/Aktif');
	}

	public function del(Request $request)
	{
		$id = $request->get('id');
		DB::table('karyawans')->where('id_karyawan',$id)->delete();
        //dd($request->get('id'));
		return redirect('/admin/karyawan/Aktif');   
	}

	public function mutasi()
	{
		$karyawan = DB::table('karyawans')->where('sts','aktif')->orderBy('id_karyawan','asc')->get();
        // dd($karyawan);
		return view('admin.mutasi',compact('karyawan'));
	}

	public function export() 
	{
		return Excel::download(new KaryawanExport, 'karyawan.xlsx');
	}

	public function storeData(Request $request)
	{
        //VALIDASI
		$this->validate($request, [
			'file' => 'required|mimes:xls,xlsx'
		]);

		if ($request->hasFile('file')) {
            $file = $request->file('file'); //GET FILE
            Excel::import(new KaryawanImport, $file); //IMPORT FILE 
            return redirect()->back()->with(['success' => 'Upload success']);
        }  
        return redirect()->back()->with(['error' => 'Please choose file before']);
    }

    public function cetak()
    {
    	$karyawan = DB::table('karyawans')->get();

    	$pdf = PDF::loadview('admin.karyawan_pdf',['karyawan'=>$karyawan]);
    	// return $pdf->download('laporan-karyawan.pdf');
    	$pdf->setPaper('A2', 'landscape');
    	return $pdf->stream('laporan-karyawan.pdf');
    }
}
