<?php

namespace App\Http\Controllers;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\MutasiExport;
use App\Imports\MutasiImport;
use DB;
use PDF;
use Illuminate\Http\Request;

class MutasiController extends Controller
{
	public function show()
	{
		$mutasi = DB::table('mutasis')
		->select(DB::raw('mutasis.*, karyawans.nama_karyawan'))
		->join('karyawans', 'mutasis.id_karyawan', '=', 'karyawans.id_karyawan')
		->get();
        // dd($karyawan);
		return view('admin.mutasi',compact('mutasi'));
	}

	public function aksi(Request $request)
	{ 
		// dd($request->get('aksi'));
		if ($request->get('aksi') == "save") {
			DB::table('mutasis')->insert([
				'id_karyawan' => $request->get('id_karyawan'),
				'bagian_asal' => $request->get('bagian_asal'),
				'seksi_asal' => $request->get('seksi_asal'),
				'posisi_asal' => $request->get('posisi_asal'),
				'bagian_tujuan' => $request->get('bagian_tujuan'),
				'seksi_tujuan' => $request->get('seksi_tujuan'),
				'posisi_tujuan' => $request->get('posisi_tujuan'),
				'tgl_mutasi' => $request->get('tgl_mutasi'),
			]);
		}
		else{
			DB::table('mutasis')
			->where('id_mutasi',$request->get('id_mutasi'))
			->update([
				'id_karyawan' => $request->get('id_karyawan'),
				'bagian_asal' => $request->get('bagian_asal'),
				'seksi_asal' => $request->get('seksi_asal'),
				'posisi_asal' => $request->get('posisi_asal'),
				'bagian_tujuan' => $request->get('bagian_tujuan'),
				'seksi_tujuan' => $request->get('seksi_tujuan'),
				'posisi_tujuan' => $request->get('posisi_tujuan'),
				'tgl_mutasi' => $request->get('tgl_mutasi'),
			]);
		}
		return redirect('/admin/mutasi');
	}

	public function del(Request $request)
	{
		$id = $request->get('id');
		DB::table('mutasis')->where('id_mutasi',$id)->delete();
        //dd($request->get('id'));
		return redirect('/admin/mutasi');   
	}

	public function export() 
	{
		return Excel::download(new MutasiExport, 'mutasi.xlsx');
	}

	public function storeData(Request $request)
	{
        //VALIDASI
		$this->validate($request, [
			'file' => 'required|mimes:xls,xlsx'
		]);

		if ($request->hasFile('file')) {
            $file = $request->file('file'); //GET FILE
            Excel::import(new MutasiImport, $file); //IMPORT FILE 
            return redirect()->back()->with(['success' => 'Upload success']);
        }  
        return redirect()->back()->with(['error' => 'Please choose file before']);
    }

    public function cetak()
    {
    	$mutasi = DB::table('mutasis')
		->select(DB::raw('mutasis.*, karyawans.nama_karyawan'))
		->join('karyawans', 'mutasis.id_karyawan', '=', 'karyawans.id_karyawan')
		->get();

    	$pdf = PDF::loadview('admin.mutasi_pdf',['mutasi'=>$mutasi]);
    	// return $pdf->download('laporan-karyawan.pdf');
    	$pdf->setPaper('A4', 'landscape');
    	return $pdf->stream('laporan-mutasi.pdf');
    }
}
