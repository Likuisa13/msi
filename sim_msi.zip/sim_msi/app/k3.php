<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class k3 extends Model
{
    protected $guarded = [];
    
}
