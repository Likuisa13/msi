<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class obat extends Model
{
    //
    protected $guarded = [];
}
