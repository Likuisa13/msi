<?php

namespace App\Exports;

use App\K3;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
class K3Export implements FromCollection, WithHeadings, ShouldAutoSize, WithEvents
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public $tgl1;
    public $tgl2;
    public function collection()
    {

        $k3 = DB::table('k3s')
        ->select(DB::raw('@no:=@no+1 AS NO, k3s.waktu, karyawans.nama_karyawan, jk, tgl_lahir, bagian, akibat,cidera,sumber,tipe,bagian_tubuh,kerugian, penyebab'))
        ->join('karyawans', 'k3s.id_karyawan', '=', 'karyawans.id_karyawan')
        ->whereBetween('waktu', [$this->tgl1, $this->tgl2])
        ->orderBy('waktu', 'asc')
        ->get();
         // dd($k3);
    	return $k3;
    }

    public function headings(): array
    {
    	return [
            'NO',
    		'WAKTU KEJADIAN',
    		'NAMA',
    		'L/P',
    		'TANGGAL LAHIR',
    		'UNIT',
            'AKIBAT',
            'CIDERA',
            'SUMBER',
            'TIPE',
            'BAGIAN TUBUH YANG CIDERA',
            'PERKIRAAN KERUGIAN',
            'PENYEBAB KECELAKAAN',
    	];
    }

    public function registerEvents(): array
    {
    	return [
    		AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:M1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(11)->setName('Calibri')->setBold(true);
            },
        ];
    }
}
