<?php

namespace App\Exports;

use App\Mutasi;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;

class MutasiExport implements FromCollection, WithHeadings, ShouldAutoSize, WithEvents
{
    /**
    * @return \Illuminate\Support\Collection
    */

    public function collection()
    {
    	$mutasi = DB::table('mutasis')
		->select(DB::raw('mutasis.id_karyawan, karyawans.nama_karyawan, mutasis.bagian_asal, mutasis.seksi_asal, mutasis.posisi_asal, mutasis.bagian_tujuan, mutasis.seksi_tujuan, mutasis.posisi_tujuan, mutasis.tgl_mutasi'))
		->join('karyawans', 'mutasis.id_karyawan', '=', 'karyawans.id_karyawan')
		->get();
    	return $mutasi;
    }

    public function headings(): array
    {
    	return [
    		'NO ID',
    		'NAMA',
    		'BAGIAN ASAL',
    		'SEKSI ASAL',
    		'POSISI ASAL',
    		'BAGIAN TUJUAN',
    		'SEKSI TUJUAN',
    		'POSISI TUJUAN',
    		'TGL MUTASI',
    	];
    }

    public function registerEvents(): array
    {
    	return [
    		AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:j1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(11)->setName('Calibri')->setBold(true);
            },
        ];
    }
}
