<?php

namespace App\Exports;

use App\Bpjs;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
class BpjsExport implements FromCollection, WithHeadings, ShouldAutoSize, WithEvents
{
    /**
    * @return \Illuminate\Support\Collection
    */

    public function collection()
    {
    	$bpjs = DB::table('bpjs')
    	->select(DB::raw('karyawans.id_karyawan, karyawans.nama_karyawan, bpjs.no_bpjs_kis, bpjs.status_bpjs, bpjs.no_bpjs_ket'))
    	->join('karyawans', 'bpjs.id_karyawan', '=', 'karyawans.id_karyawan')
    	->get();
    	return $bpjs;
    }

    public function headings(): array
    {
    	return [
    		'NO ID',
    		'NAMA',
    		'NO BPJS KES/KIS',
    		'STATUS',
    		'NO BPJS KET',
    	];
    }

    public function registerEvents(): array
    {
    	return [
    		AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:E1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(11)->setName('Calibri')->setBold(true);
            },
        ];
    }
}

