<?php

namespace App\Exports;

use App\Obat_masuk;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
class ObatMskExport implements FromCollection, WithHeadings, ShouldAutoSize, WithEvents
{
    /**
    * @return \Illuminate\Support\Collection
    */
	public $tgl1;
    public $tgl2;
    public function collection()
    {
    	$obat_masuk = DB::table('obat_masuks')
		->select(DB::raw('obats.nama_obat, obat_masuks.tgl_masuk, sumber, jumlah, satuan'))
		->join('obats', 'obat_masuks.id_obat', '=', 'obats.id_obat')
		->whereBetween('tgl_masuk', [$this->tgl1, $this->tgl2])
		->orderBy('tgl_masuk', 'asc')
		->get();
    	return $obat_masuk;
    }
    
    public function headings(): array
    {
    	return [
    		'NAMA OBAT',
    		'TANGGAL MASUK',
    		'SUMBER',
    		'JUMLAH',
    		'SATUAN',
    	];
    }

    public function registerEvents(): array
    {
    	return [
    		AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:E1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(11)->setName('Calibri')->setBold(true);
            },
        ];
    }
}
