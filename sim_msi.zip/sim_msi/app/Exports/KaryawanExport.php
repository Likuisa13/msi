<?php

namespace App\Exports;

use App\Karyawan;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
class KaryawanExport implements FromCollection, WithHeadings, ShouldAutoSize, WithEvents
{
    /**
    * @return \Illuminate\Support\Collection
    */

    public function collection()
    {
    	$karyawan = DB::table('karyawans')->get();
    	return $karyawan;
    }

    public function headings(): array
    {
    	return [
    		'NO ID',
			'NAMA',
			'TANGGAL MASUK',
			'BAGIAN',
			'SEKSI',
			'JABATAN',
			'STATUS PEG',
			'NO KONTRAK 1',
			'AWAL KONTRAK 1',
			'AKHIR KONTRAK 1',
			'NO KONTRAK 2',
			'AWAL KONTRAK 2',
			'AKHIR KONTRAK 2',
			'NO KTP',
			'PENDIDIKAN',
			// 'NO BPJS KES/KIS',
			// 'NO BPJS KET',
			'TEMPAT LAHIR',
			'TANGGAL LAHIR',
			'L/P',
			'STATUS',
			'JML ANAK',
			'ALAMAT',
			'SUAMI/ISTRI',
			'NO TELP',
			'NO TELP LAIN',
			'E-MAIL',
			'AGAMA',
			'STATUS',
			'Created At',
			'Updated At'
    	];
    }

    public function registerEvents(): array
    {
    	return [
    		AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:Z1'; // All headers
                // $cell = 'A2:AD10000';
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(11)->setName('Calibri')->setBold(true);
                // $event->sheet->getDelegate()->getStyle($cell)->getFont()->setSize(11)->setName('Calibri');
            },
        ];
    }
}
