<?php

namespace App\Exports;

use App\Obat_keluar;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;

class ObatKeluarExport implements FromCollection, WithHeadings, ShouldAutoSize, WithEvents
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public $tgl1;
    public $tgl2;
    public function collection()
    {
    	$obat_keluar = DB::table('obat_keluars')
		->select(DB::raw('tgl_keluar, nama_karyawan, nama_obat, jumlah, satuan, keluhan'))
		->join('obats', 'obat_keluars.id_obat', '=', 'obats.id_obat')
		->join('karyawans', 'obat_keluars.id_karyawan', '=', 'karyawans.id_karyawan')
		->whereBetween('tgl_keluar', [$this->tgl1, $this->tgl2])
		->orderBy('tgl_keluar', 'asc')
		->get();
    	return $obat_keluar;
    }
    
    public function headings(): array
    {
    	return [
    		'TANGGAL KELUAR',
    		'NAMA KARYAWAN',
    		'NAMA OBAT',
    		'JUMLAH',
    		'SATUAN',
    		'KELUHAN',
    	];
    }

    public function registerEvents(): array
    {
    	return [
    		AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:F1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(11)->setName('Calibri')->setBold(true);
            },
        ];
    }
}
