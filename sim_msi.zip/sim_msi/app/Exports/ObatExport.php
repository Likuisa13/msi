<?php

namespace App\Exports;

use App\Obat;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;

class ObatExport implements FromCollection, WithHeadings, ShouldAutoSize, WithEvents
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
    	$obat = DB::table('obats')
    	->select(DB::raw('nama_obat, jenis_obat, stok, satuan'))
    	->orderBy('nama_obat', 'asc')
    	->get();
    	return $obat;
    }
    
    public function headings(): array
    {
    	return [
    		'NAMA OBAT',
    		'JENIS OBAT',
    		'STOK',
    		'SATUAN',
    	];
    }

    public function registerEvents(): array
    {
    	return [
    		AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:D1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(11)->setName('Calibri')->setBold(true);
            },
        ];
    }
}
