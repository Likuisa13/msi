<?php

namespace App\Exports;

use App\Resign;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Events\AfterSheet;
use DB;
class ResignExport implements FromCollection, WithHeadings, ShouldAutoSize, WithEvents
{
    /**
    * @return \Illuminate\Support\Collection
    */

    public function collection()
    {
    	$k3 = DB::table('k3s')
        ->select(DB::raw('k3s.*, karyawans.nama_karyawan'))
        ->join('karyawans', 'k3s.id_karyawan', '=', 'karyawans.id_karyawan')
        ->get();
    	return $k3;
    }

    public function headings(): array
    {
    	return [
    		'NO ID',
    		'NAMA',
    		'TANGGAL RESIGN',
    		'JENIS RESIGN',
    		'KETERANGAN',
    	];
    }

    public function registerEvents(): array
    {
    	return [
    		AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:F1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(11)->setName('Calibri')->setBold(true);
            },
        ];
    }
}
