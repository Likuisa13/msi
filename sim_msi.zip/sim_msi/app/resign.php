<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class resign extends Model
{
    //
    protected $guarded = [];
    
}
