<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class obat_keluar extends Model
{
    //
}
