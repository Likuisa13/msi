<!DOCTYPE html>
<html>
<head>
	<title>Cetak Data Mutasi</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h2>Data Mutasi Karyawan</h2></center><br>
		<table class="table table-bordered">
			<thead>
				<tr>
					<td>No</td>
					<td><center>Nama</center></td>
					<td><center>ID</center></td>
					<td><center>BAGIAN ASAL</center></td>
					<td><center>SEKSI ASAL</center></td>
					<td><center>JABATAN ASAL</center></td>
					<td><center>BAGIAN TUJUAN</center></td>
					<td><center>SEKSI TUJUAN</center></td>
					<td><center>JABATAN TUJUAN</center></td>
					<td><center>TGL MUTASI</center></td>
				</tr>
			</thead>
			<tbody>
				@php $i=1 @endphp
				@foreach($mutasi as $b)
				<tr>
					<td>{{ $i++ }}</td>
					<td>{{$b->nama_karyawan}}</td>
					<td>{{$b->id_karyawan}}</td>
					<td>{{$b->bagian_asal}}</td>
					<td>{{$b->seksi_asal}}</td>
					<td>{{$b->posisi_asal}}</td>
					<td>{{$b->bagian_tujuan}}</td>
					<td>{{$b->seksi_tujuan}}</td>
					<td>{{$b->posisi_tujuan}}</td>
					<td>{{$b->tgl_mutasi}}</td>
				</tr>
				@endforeach
			</tbody>
		</table>

	</body>
	</html>