<!DOCTYPE html>
<html>
<head>
	<title>Cetak Data Resign</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h2>Data Resign Karyawan</h2></center><br>
		<table class="table table-bordered">
			<thead>
				<tr>
					<td>No</td>
					<td><center>Nama</center></td>
					<td><center>ID</center></td>
					<td><center>Tanggal Resign</center></td>
					<td><center>Jenis Resign</center></td>
					<td><center>Keterangan</center></td>
				</tr>
			</thead>
			<tbody>
				@php $i=1 @endphp
				@foreach($resign as $b)
				<tr>
					<td>{{ $i++ }}</td>
					<td>{{$b->nama_karyawan}}</td>
					<td>{{$b->id_karyawan}}</td>
					<td>{{$b->tgl_resign}}</td>
					<td>{{$b->jenis_resign}}</td>
					<td>{{$b->keterangan}}</td>
				</tr>
				@endforeach
			</tbody>
		</table>

	</body>
	</html>