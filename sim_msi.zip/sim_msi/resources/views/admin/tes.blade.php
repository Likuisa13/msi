<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Uji Coba</h2>
{{ $karyawan ->$nama_karyawan}}
</body>
</html>