<!DOCTYPE html>
<html>
<head>
	<title>Cetak Data Karyawan</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h1>Data Karyawan</h1></center>
		<table class="table table-bordered">
			<thead>
				<tr>
					<td>No</td>
					<td><center>Nama</center></td>
					<td><center>ID</center></td>
					<td><center>Tanggal Masuk</center></td>
					<td><center>Bagian</center></td>
					<td><center>Seksi</center></td>
					<td><center>Posisi</center></td>
					<td><center>Status Peg</center></td>
					<td><center>No Kontrak 1</center></td>
					<td><center>Masa Kontrak 1</center></td>
					<td><center>No Kontrak 2</center></td>
					<td><center>Masa Kontrak 2</center></td>
					<td><center>No KTP</center></td>
					<td><center>Pendidikan</center></td>
					<td><center>Tempat,Tanggal Lahir</center></td>
					<td><center>L/P</center></td>
					<td><center>Status</center></td>
					<td><center>Jml Anak</center></td>
					<td><center>Suami/Istri</center></td>
					<td><center>Alamat</center></td>
					<td><center>No Telp</center></td>
					<td><center>No Telp Lain</center></td>
					<td><center>Email</center></td>
					<td><center>Agama</center></td>
				</tr>
			</thead>
			<tbody>
				@php $i=1 @endphp
				@foreach($karyawan as $kary)
				<tr>
					<td>{{ $i++ }}</td>
					<td>{{$kary->nama_karyawan}}</td>
					<td>{{$kary->id_karyawan}}</td>
					<td>{{$kary->tgl_masuk}}</td>
					<td>{{$kary->bagian}}</td>
					<td>{{$kary->seksi}}</td>
					<td>{{$kary->posisi}}</td>
					<td>{{$kary->status_peg}}</td>
					<td>{{$kary->no_k1}}</td>
					<td>{{$kary->k1_awal}} S/D {{$kary->k1_akhir}}</td>
					<td>{{$kary->no_k2}}</td>
					<td>{{$kary->k2_awal}} S/D {{$kary->k2_akhir}}</td>
					<td>{{$kary->no_ktp}}</td>
					<td>{{$kary->pendidikan}}</td>
					<td>{{$kary->tempat_lahir}}, {{ $kary->tgl_lahir }}</td>
					<td>{{$kary->jk}}</td>
					<td>{{$kary->status}}</td>
					<td>{{$kary->anak}}</td>
					<td>{{$kary->pasangan}}</td>
					<td>{{$kary->alamat}}</td>
					<td>{{$kary->telp}}</td>
					<td>{{$kary->hp}}</td>
					<td>{{$kary->email}}</td>
					<td>{{$kary->agama}}</td>
				</tr>
				@endforeach
			</tbody>
		</table>

	</body>
	</html>