<!DOCTYPE html>
<html>
<head>
	<title>Cetak Data BPJS</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h2>Data Mutasi Karyawan</h2></center><br>
		<table class="table table-bordered">
			<thead>
				<tr>
					<td>No</td>
					<td><center>Nama</center></td>
					<td><center>ID</center></td>
					<td><center>BAGIAN ASAL</center></td>
					<td><center>SEKSI ASAL</center></td>
					<td><center>JABATAN ASAL</center></td>
					<td><center>BAGIAN TUJUAN</center></td>
					<td><center>SEKSI TUJUAN</center></td>
					<td><center>JABATAN TUJUAN</center></td>
					<td><center>TGL MUTASI</center></td>
				</tr>
			</thead>
			<tbody>
				<?php $i=1 ?>
				<?php $__currentLoopData = $mutasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td><?php echo e($i++); ?></td>
					<td><?php echo e($b->nama_karyawan); ?></td>
					<td><?php echo e($b->id_karyawan); ?></td>
					<td><?php echo e($b->bagian_asal); ?></td>
					<td><?php echo e($b->seksi_asal); ?></td>
					<td><?php echo e($b->posisi_asal); ?></td>
					<td><?php echo e($b->bagian_tujuan); ?></td>
					<td><?php echo e($b->seksi_tujuan); ?></td>
					<td><?php echo e($b->posisi_tujuan); ?></td>
					<td><?php echo e($b->tgl_mutasi); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</tbody>
		</table>

	</body>
	</html><?php /**PATH D:\laravel\sim_msi\resources\views/admin/mutasi_pdf.blade.php ENDPATH**/ ?>