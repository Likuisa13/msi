<?php echo e($slot); ?>

<?php /**PATH D:\Dwiki Nitip\Laravel\laravel\sim_msi\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>