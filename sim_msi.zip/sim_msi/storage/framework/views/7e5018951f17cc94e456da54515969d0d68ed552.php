<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>Data Karyawan</title>
    <link rel="icon" href="/images/icon/logo.png">
    <!-- Fontfaces CSS-->
    <link href="/css/font-face.css" rel="stylesheet" media="all">
    <link href="/vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="/vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="/vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="/vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="/vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="/vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="/vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="/vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="/vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="/vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="/vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="/css/theme.css" rel="stylesheet" media="all">
    <link rel="stylesheet" href="/css/dataTables.bootstrap4.min.css">
    <script type="text/javascript"> 
        function delKary(id,nm) {
            $('#id').val(id);
            $('#nmkar').text(nm);
            $('#DelKar').modal('show');                
        }  
        function detKary(id_karyawan,nama_karyawan,bagian,tgl_masuk,posisi,seksi,no_k1,k1_awal,k1_akhir,no_k2,k2_awal,k2_akhir,status_peg,pendidikan,no_ktp,tempat_lahir,tgl_lahir,jk,agama,email,status,pasangan,anak,telp,hp,alamat) {
            $('#idedit').val(id_karyawan);
            $('#id_karyawan').val(id_karyawan);
            $('#nama_karyawan').val(nama_karyawan);
            $('#bagian').val(bagian);
            $('#tgl_masuk').val(tgl_masuk);
            $('#posisi').val(posisi);
            $('#seksi').val(seksi);
            $('#no_k1').val(no_k1);
            $('#k1_awal').val(k1_awal);
            $('#k1_akhir').val(k1_akhir);
            $('#no_k2').val(no_k2);
            $('#k2_awal').val(k2_awal);
            $('#k2_akhir').val(k2_akhir);
            $('#status_peg').val(status_peg);
            $('#pendidikan').val(pendidikan);
            $('#no_ktp').val(no_ktp);
            $('#tempat_lahir').val(tempat_lahir);
            $('#tgl_lahir').val(tgl_lahir);
            $('#jk').val(jk);
            $('#agama').val(agama);
            $('#email').val(email);
            $('#status').val(status);
            $('#pasangan').val(pasangan);
            $('#anak').val(anak);
            $('#telp').val(telp);
            $('#hp').val(hp);
            $('#alamat').val(alamat);
            // $('#no_bpjs_kis').val(no_bpjs_kis);
            // $('#no_bpjs_kerja').val(no_bpjs_kerja);
            document.getElementById("id_karyawan").readOnly = true;
            document.getElementById("nama_karyawan").readOnly = true;
            document.getElementById("bagian").readOnly = true;
            document.getElementById("tgl_masuk").readOnly = true;
            document.getElementById("posisi").readOnly = true;
            document.getElementById("seksi").readOnly = true;
            document.getElementById("no_k1").readOnly = true;
            document.getElementById("k1_awal").readOnly = true;
            document.getElementById("k1_akhir").readOnly = true;
            document.getElementById("no_k2").readOnly = true;
            document.getElementById("k2_awal").readOnly = true;
            document.getElementById("k2_akhir").readOnly = true;
            document.getElementById("status_peg").readOnly = true;
            document.getElementById("pendidikan").readOnly = true;
            document.getElementById("no_ktp").readOnly = true;
            document.getElementById("tempat_lahir").readOnly = true;
            document.getElementById("tgl_lahir").readOnly = true;
            document.getElementById("jk").readOnly = true;
            document.getElementById("agama").readOnly = true;
            document.getElementById("email").readOnly = true;
            document.getElementById("status").readOnly = true;
            document.getElementById("pasangan").readOnly = true;
            document.getElementById("anak").readOnly = true;
            document.getElementById("telp").readOnly = true;
            document.getElementById("hp").readOnly = true;
            document.getElementById("alamat").readOnly = true;
            // document.getElementById("no_bpjs_kis").readOnly = true;
            // document.getElementById("no_bpjs_kerja").readOnly = true;
            document.getElementById('tombol').style.visibility = 'hidden';
            $('#DetKar').modal('show');                
        }  

        function upKary(id_karyawan,nama_karyawan,bagian,tgl_masuk,posisi,seksi,no_k1,k1_awal,k1_akhir,no_k2,k2_awal,k2_akhir,status_peg,pendidikan,no_ktp,tempat_lahir,tgl_lahir,jk,agama,email,status,pasangan,anak,telp,hp,alamat) {            // $('#id').val(id);
        $('#idedit').val(id_karyawan);
        $('#id_karyawan').val(id_karyawan);
        $('#nama_karyawan').val(nama_karyawan);
        $('#bagian').val(bagian);
        $('#tgl_masuk').val(tgl_masuk);
        $('#posisi').val(posisi);
        $('#seksi').val(seksi);
        $('#no_k1').val(no_k1);
        $('#k1_awal').val(k1_awal);
        $('#k1_akhir').val(k1_akhir);
        $('#no_k2').val(no_k2);
        $('#k2_awal').val(k2_awal);
        $('#k2_akhir').val(k2_akhir);
        $('#status_peg').val(status_peg);
        $('#pendidikan').val(pendidikan);
        $('#no_ktp').val(no_ktp);
        $('#tempat_lahir').val(tempat_lahir);
        $('#tgl_lahir').val(tgl_lahir);
        $('#jk').val(jk);
        $('#agama').val(agama);
        $('#email').val(email);
        $('#status').val(status);
        $('#pasangan').val(pasangan);
        $('#anak').val(anak);
        $('#telp').val(telp);
        $('#hp').val(hp);
        $('#alamat').val(alamat);
        // $('#no_bpjs_kis').val(no_bpjs_kis);
        // $('#no_bpjs_kerja').val(no_bpjs_kerja);
        document.getElementById("id_karyawan").readOnly = false;
        document.getElementById("nama_karyawan").readOnly = false;
        document.getElementById("bagian").readOnly = false;
        document.getElementById("tgl_masuk").readOnly = false;
        document.getElementById("posisi").readOnly = false;
        document.getElementById("seksi").readOnly = false;
        document.getElementById("no_k1").readOnly = false;
        document.getElementById("k1_awal").readOnly = false;
        document.getElementById("k1_akhir").readOnly = false;
        document.getElementById("no_k2").readOnly = false;
        document.getElementById("k2_awal").readOnly = false;
        document.getElementById("k2_akhir").readOnly = false;
        document.getElementById("status_peg").readOnly = false;
        document.getElementById("pendidikan").readOnly = false;
        document.getElementById("no_ktp").readOnly = false;
        document.getElementById("tempat_lahir").readOnly = false;
        document.getElementById("tgl_lahir").readOnly = false;
        document.getElementById("jk").readOnly = false;
        document.getElementById("agama").readOnly = false;
        document.getElementById("email").readOnly = false;
        document.getElementById("status").readOnly = false;
        document.getElementById("pasangan").readOnly = false;
        document.getElementById("anak").readOnly = false;
        document.getElementById("telp").readOnly = false;
        document.getElementById("hp").readOnly = false;
        document.getElementById("alamat").readOnly = false;
        // document.getElementById("no_bpjs_kis").readOnly = false;
        // document.getElementById("no_bpjs_kerja").readOnly = false;
        document.getElementById('tombol').style.visibility = 'visible';
        $('#DetKar').modal('show');                
    } 
</script>
</head>

<body class="animsition">
    <div class="page-wrapper">
        <!-- HEADER MOBILE-->
        <header class="header-mobile d-block d-lg-none">
            <div class="header-mobile__bar">
                <div class="container-fluid">
                    <div class="header-mobile-inner">
                        <a class="logo" href="index.html">
                            <img src="/images/icon/logo2.png" alt="CoolAdmin" />
                        </a>
                        <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                        </button>
                    </div>
                </div>
            </div> 
            <nav class="navbar-mobile">
                <div class="container-fluid">
                    <ul class="navbar-mobile__list list-unstyled">
                        <li>
                            <a class="js-arrow" href="/admin/home">
                                <i class="fas fa-tachometer-alt"></i> Dashboard</a>
                            </li>
                            <li class="has-sub">
                                <a class="js-arrow" href="#">
                                    <i class="fa fa-users"></i>Karyawan</a>
                                    <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                        <li>
                                            <a href="/admin/karyawan/Aktif">Data Karyawan</a>
                                        </li>
                                        <li>
                                            <a href="/admin/mutasi">Mutasi</a>
                                        </li>
                                        <li>
                                            <a href="/admin/bpjs">BPJS</a>
                                        </li>
                                        <li>
                                            <a href="/admin/resign">Resign</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="has-sub">
                                    <a class="js-arrow" href="#">
                                        <i class="fa fa-ambulance"></i>K3</a>
                                        <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                            <li>
                                                <a href="/admin/obat">Stok Obat</a>
                                            </li>
                                            <li>
                                                <a href="/admin/obat/masuk">Obat Masuk</a>
                                            </li>
                                            <li>
                                                <a href="/admin/obat/keluar">Obat Keluar</a>
                                            </li>
                                            <li>
                                                <a href="/admin/k3">Kecelakaan</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                            </div>
                        </nav>
                    </header>
                    <!-- END HEADER MOBILE-->

                    <!-- MENU SIDEBAR-->
                    <aside class="menu-sidebar d-none d-lg-block">
                        <div class="logo">
                            <a href="#">
                                <img src="/images/icon/logo2.png" alt="Cool Admin" />
                            </a>
                        </div>
                        <div class="menu-sidebar__content js-scrollbar1">
                            <nav class="navbar-sidebar">
                                <ul class="list-unstyled navbar__list">
                                    <li class="active has-sub">
                                        <a class="js-arrow" href="/admin/home">
                                            <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                                        </li>
                                        <li class="has-sub">
                                            <a class="js-arrow" href="#">
                                                <i class="fa fa-users"></i>Karyawan</a>
                                                <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                                    <li>
                                                        <a href="/admin/karyawan/Aktif">Data Karyawan</a>
                                                    </li>
                                                    <li>
                                                        <a href="/admin/mutasi">Mutasi</a>
                                                    </li>
                                                    <li>
                                                        <a href="/admin/bpjs">BPJS</a>
                                                    </li>
                                                    <li>
                                                        <a href="/admin/resign">Resign</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="has-sub">
                                                <a class="js-arrow" href="#">
                                                    <i class="fa fa-ambulance"></i>K3</a>
                                                    <ul class="navbar-mobile-sub__list list-unstyled js-sub-list">
                                                        <li>
                                                            <a href="/admin/obat">Stok Obat</a>
                                                        </li>
                                                        <li>
                                                            <a href="/admin/obat/masuk">Obat Masuk</a>
                                                        </li>
                                                        <li>
                                                            <a href="/admin/obat/keluar">Obat Keluar</a>
                                                        </li>
                                                        <li>
                                                            <a href="/admin/k3">Kecelakaan</a>
                                                        </li>
                                                    </ul>
                                                </li>
                                            </nav>
                                        </div>
                                    </aside>
                                    <!-- END MENU SIDEBAR-->

                                    <!-- PAGE CONTAINER-->
                                    <div class="page-container">
                                        <!-- HEADER DESKTOP-->
                                        <header class="header-desktop">
                                            <div class="section__content section__content--p30">
                                                <div class="container-fluid">
                                                    <div class="header-wrap">
                                                        <div class="col-sm-6"></div>
                                                        <div class="header-button">
                                                            <div class="noti-wrap">
                                                                <div class="noti__item js-item-menu">
                                                                    <i class="zmdi zmdi-comment-more"></i>
                                                                    <span class="quantity">1</span>
                                                                    <div class="mess-dropdown js-dropdown">
                                                                        <div class="mess__title">
                                                                            <p>You have 2 news message</p>
                                                                        </div>
                                                                        <div class="mess__item">
                                                                            <div class="image img-cir img-40">
                                                                                <img src="/images/icon/avatar-06.jpg" alt="Michelle Moreno" />
                                                                            </div>
                                                                            <div class="content">
                                                                                <h6>Michelle Moreno</h6>
                                                                                <p>Have sent a photo</p>
                                                                                <span class="time">3 min ago</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mess__item">
                                                                            <div class="image img-cir img-40">
                                                                                <img src="/images/icon/avatar-04.jpg" alt="Diane Myers" />
                                                                            </div>
                                                                            <div class="content">
                                                                                <h6>Diane Myers</h6>
                                                                                <p>You are now connected on message</p>
                                                                                <span class="time">Yesterday</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="mess__footer">
                                                                            <a href="#">View all messages</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="noti__item js-item-menu">
                                                                    <i class="zmdi zmdi-email"></i>
                                                                    <span class="quantity">1</span>
                                                                    <div class="email-dropdown js-dropdown">
                                                                        <div class="email__title">
                                                                            <p>You have 3 New Emails</p>
                                                                        </div>
                                                                        <div class="email__item">
                                                                            <div class="image img-cir img-40">
                                                                                <img src="/images/icon/avatar-06.jpg" alt="Cynthia Harvey" />
                                                                            </div>
                                                                            <div class="content">
                                                                                <p>Meeting about new dashboard...</p>
                                                                                <span>Cynthia Harvey, 3 min ago</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="email__item">
                                                                            <div class="image img-cir img-40">
                                                                                <img src="/images/icon/avatar-05.jpg" alt="Cynthia Harvey" />
                                                                            </div>
                                                                            <div class="content">
                                                                                <p>Meeting about new dashboard...</p>
                                                                                <span>Cynthia Harvey, Yesterday</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="email__item">
                                                                            <div class="image img-cir img-40">
                                                                                <img src="/images/icon/avatar-04.jpg" alt="Cynthia Harvey" />
                                                                            </div>
                                                                            <div class="content">
                                                                                <p>Meeting about new dashboard...</p>
                                                                                <span>Cynthia Harvey, April 12,,2018</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="email__footer">
                                                                            <a href="#">See all emails</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <div class="noti__item js-item-menu">
                                                                    <i class="zmdi zmdi-notifications"></i>
                                                                    <span class="quantity">3</span>
                                                                    <div class="notifi-dropdown js-dropdown">
                                                                        <div class="notifi__title">
                                                                            <p>You have 3 Notifications</p>
                                                                        </div>
                                                                        <div class="notifi__item">
                                                                            <div class="bg-c1 img-cir img-40">
                                                                                <i class="zmdi zmdi-email-open"></i>
                                                                            </div>
                                                                            <div class="content">
                                                                                <p>You got a email notification</p>
                                                                                <span class="date">April 12, 2018 06:50</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="notifi__item">
                                                                            <div class="bg-c2 img-cir img-40">
                                                                                <i class="zmdi zmdi-account-box"></i>
                                                                            </div>
                                                                            <div class="content">
                                                                                <p>Your account has been blocked</p>
                                                                                <span class="date">April 12, 2018 06:50</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="notifi__item">
                                                                            <div class="bg-c3 img-cir img-40">
                                                                                <i class="zmdi zmdi-file-text"></i>
                                                                            </div>
                                                                            <div class="content">
                                                                                <p>You got a new file</p>
                                                                                <span class="date">April 12, 2018 06:50</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="notifi__footer">
                                                                            <a href="#">All notifications</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="account-wrap">
                                                                <div class="account-item clearfix js-item-menu">
                                                                    <div class="image">
                                                                        <img src="/images/icon/avatar-01.jpg" alt="John Doe" />
                                                                    </div>
                                                                    <div class="content">
                                                                        <a class="js-acc-btn" href="#">john doe</a>
                                                                    </div>
                                                                    <div class="account-dropdown js-dropdown">
                                                                        <div class="info clearfix">
                                                                            <div class="image">
                                                                                <a href="#">
                                                                                    <img src="/images/icon/avatar-01.jpg" alt="John Doe" />
                                                                                </a>
                                                                            </div>
                                                                            <div class="content">
                                                                                <h5 class="name">
                                                                                    <a href="#">john doe</a>
                                                                                </h5>
                                                                                <span class="email">johndoe@example.com</span>
                                                                            </div>
                                                                        </div>
                                                                        <div class="account-dropdown__body">
                                                                            <div class="account-dropdown__item">
                                                                                <a href="#">
                                                                                    <i class="zmdi zmdi-account"></i>Account</a>
                                                                                </div>
                                                                                <div class="account-dropdown__item">
                                                                                    <a href="#">
                                                                                        <i class="zmdi zmdi-settings"></i>Setting</a>
                                                                                    </div>
                                                                                    <div class="account-dropdown__item">
                                                                                        <a href="#">
                                                                                            <i class="zmdi zmdi-money-box"></i>Billing</a>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="account-dropdown__footer">
                                                                                        <a href="#">
                                                                                            <i class="zmdi zmdi-power"></i>Logout</a>
                                                                                        </div>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </header>
                                                        <!-- HEADER DESKTOP-->
                                                        <div class="main-content">
                                                            <div class="section__content section__content--p30">
                                                                <div class="container-fluid">
                                                                    <?php ;
                                                                    ?>
                                                                    <h2><center>Data Karyawan</center></h2>
                                                                    <div>
                                                                        <a href="<?php echo e(route('addkary')); ?>"><button class="btn btn-primary btn-sm" title="Tambah Data"><i class="fa fa-plus"></i></button></a>
                                                                        <button data-toggle="modal" data-target="#upload" class="btn btn-danger btn-sm" title="Import Data"><i class="fa fa-upload"></i></button>
                                                                        <a href="<?php echo e(route('export-karyawan')); ?>" target="_blank" rel="nofollow"><button class="btn btn-dark btn-sm" title="Export Data"><i class="fa fa-download"></i></button></a>
                                                                        <a href="<?php echo e(route('print-kary')); ?>" target="_blank" rel="nofollow"><button class="btn btn-info btn-sm" title="Cetak Data"><i class="fa fa-print"></i></button></a>
                                                                    </div><br>
                                                                    <div class="table-responsive">
                                                                        <table id="karyawan" class="table table-borderless table-striped table-earning">
                                                                            <thead class="btn-dark readOnly"><tr>
                                                                                <td><center>No</center></td>
                                                                                <td><center>Nama</center></td>
                                                                                <td><center>ID</center></td>
                                                                                <td><center>Bagian</center></td>
                                                                                <td><center>Posisi</center></td>
                                                                                <!-- <td><center>Seksi</center></td> -->
                                                                                <td><center>Aksi</center></td>
                                                                            </tr></thead>
                                                                            <?php if($karyawan): ?>
                                                                            <?php $__currentLoopData = $karyawan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <tr>
                                                                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                                                                <td><?php echo e($data->nama_karyawan); ?></td>
                                                                                <td><?php echo e($data->id_karyawan); ?></td>
                                                                                <td><?php echo e($data->bagian); ?></td>
                                                                                <td><?php echo e($data->posisi); ?></td>
                                                                                <!-- <td><?php echo e($data->seksi); ?></td> -->
                                                                                <td nowrap="">
                                                                                    <button type="button" onclick="detKary('<?php echo e($data->id_karyawan); ?>','<?php echo e($data->nama_karyawan); ?>','<?php echo e($data->bagian); ?>','<?php echo e($data->tgl_masuk); ?>','<?php echo e($data->posisi); ?>','<?php echo e($data->seksi); ?>','<?php echo e($data->no_k1); ?>','<?php echo e($data->k1_awal); ?>','<?php echo e($data->k1_akhir); ?>','<?php echo e($data->no_k2); ?>','<?php echo e($data->k2_awal); ?>','<?php echo e($data->k2_akhir); ?>','<?php echo e($data->status_peg); ?>','<?php echo e($data->pendidikan); ?>','<?php echo e($data->no_ktp); ?>','<?php echo e($data->tempat_lahir); ?>','<?php echo e($data->tgl_lahir); ?>','<?php echo e($data->jk); ?>','<?php echo e($data->agama); ?>','<?php echo e($data->email); ?>','<?php echo e($data->status); ?>','<?php echo e($data->pasangan); ?>','<?php echo e($data->anak); ?>','<?php echo e($data->telp); ?>','<?php echo e($data->hp); ?>','<?php echo e($data->alamat); ?>');" class="" title="Detail"><i class="fa fa-list"></i></button>
                                                                                    <button type="button" onclick="upKary('<?php echo e($data->id_karyawan); ?>','<?php echo e($data->nama_karyawan); ?>','<?php echo e($data->bagian); ?>','<?php echo e($data->tgl_masuk); ?>','<?php echo e($data->posisi); ?>','<?php echo e($data->seksi); ?>','<?php echo e($data->no_k1); ?>','<?php echo e($data->k1_awal); ?>','<?php echo e($data->k1_akhir); ?>','<?php echo e($data->no_k2); ?>','<?php echo e($data->k2_awal); ?>','<?php echo e($data->k2_akhir); ?>','<?php echo e($data->status_peg); ?>','<?php echo e($data->pendidikan); ?>','<?php echo e($data->no_ktp); ?>','<?php echo e($data->tempat_lahir); ?>','<?php echo e($data->tgl_lahir); ?>','<?php echo e($data->jk); ?>','<?php echo e($data->agama); ?>','<?php echo e($data->email); ?>','<?php echo e($data->status); ?>','<?php echo e($data->pasangan); ?>','<?php echo e($data->anak); ?>','<?php echo e($data->telp); ?>','<?php echo e($data->hp); ?>','<?php echo e($data->alamat); ?>');" class="" title="Edit"><i class="fa fa-edit"></i></button>
                                                                                    <button type="button" onclick="delKary('<?php echo e($data->id_karyawan); ?>','<?php echo e($data->nama_karyawan); ?>');" class="" title="Hapus"><i class="fa fa-trash"></i></button>
                                                                                </td></tr>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php endif; ?>

                                                                            </table>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- modal upload -->
                                                        <div class="modal fade" id="upload" tabindex="-1" role="dialog" aria-labelledby="DialogModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog modal-sm" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="staticModalLabel"><center>Import Data Karyawan</center></h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="container-fluid">
                                                                        <form action="<?php echo e(url('/admin/imkary')); ?>" method="post" enctype="multipart/form-data">
                                                                            <?php echo csrf_field(); ?>
                                                                            <?php if(session('success')): ?>
                                                                            <div class="alert alert-success">
                                                                                <?php echo e(session('success')); ?>

                                                                            </div>
                                                                            <?php endif; ?>

                                                                            <?php if(session('error')): ?>
                                                                            <div class="alert alert-success">
                                                                                <?php echo e(session('error')); ?>

                                                                            </div>
                                                                            <?php endif; ?>

                                                                            <div class="form-group">
                                                                                <label for="">Pilih File (.xls, .xlsx)</label>
                                                                                <input type="file" class="form-control" name="file">
                                                                                Download Format Excel <a href="/excel/Format Import Karyawan.xlsx" target="_blank" rel="nofollow">DI SINI</button></a>

                                                                                <p class="text-danger"><?php echo e($errors->first('file')); ?></p>
                                                                            </div>
                                                                            <div class="form-group">
                                                                                <button class="btn btn-primary btn-sm">Upload</button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- end modal upload -->
                                                        <!-- modal static -->
                                                        <div class="modal fade" id="DelKar" tabindex="-1" role="dialog" aria-labelledby="DialogModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog modal-sm" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h5 class="modal-title" id="staticModalLabel"><center>Hapus Data Karyawan</center></h5>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <form action="/admin/karyawan-del/" method="post">
                                                                        <?php echo csrf_field(); ?>
                                                                        <div class="modal-body">
                                                                            <span>Yakin akan menghapus data</span>
                                                                            <input type="hidden" id="id" name="id">
                                                                            <h3 id="nmkar"></h3>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="submit" class="btn btn-danger">Ya, Hapus</button>
                                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <!-- end modal static -->
                                                        <!-- modal scroll -->
                                                        <div class="modal fade" id="DetKar" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true">
                                                            <div class="modal-dialog modal-lg" role="document">
                                                                <div class="modal-content">
                                                                    <div class="modal-header">
                                                                        <h3 class="modal-title" id="scrollmodalLabel"><center><strong>Data Karyawan</strong></center></h3>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">&times;</span>
                                                                        </button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="container-fluid">
                                                                            <div class="card-body">
                                                                                <form action="/admin/karyawan-update" method="POST">
                                                                                    <?php echo csrf_field(); ?>
                                                                                    <div class="row">
                                                                                        <div class="col-sm-3">
                                                                                            <label>ID Karyawan</label>
                                                                                            <input type="hidden" id="idedit" name="idedit" class="form-control">
                                                                                            <input type="text" id="id_karyawan" name="id_karyawan" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-6">
                                                                                            <label>Nama Karyawan</label>
                                                                                            <input type="text" id="nama_karyawan" name="nama_karyawan" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>Jenis Kelamin</label>
                                                                                            <select class="form-control" id="jk" name="jk">
                                                                                                <option value="0">Jenis Kelamin</option>
                                                                                                <option value="L">Laki-Laki</option>
                                                                                                <option value="P">Perempuan</option>
                                                                                            </select>
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-sm-3">
                                                                                            <label>Tempat Lahir</label>
                                                                                            <input type="text" id="tempat_lahir" name="tempat_lahir" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>Tanggal Lahir</label>
                                                                                            <input type="date" id="tgl_lahir" name="tgl_lahir" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>Agama</label>
                                                                                            <select class="form-control" id="agama" name="agama">
                                                                                                <option value="0">Pilih Agama</option>
                                                                                                <option value="Islam">Islam</option>
                                                                                                <option value="Katholik">Katholik</option>
                                                                                                <option value="Protestan">Protestan</option>
                                                                                                <option value="Hindu">Hindu</option>
                                                                                                <option value="Budha">Budha</option>
                                                                                                <option value="Konghucu">Konghucu</option>
                                                                                            </select>
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>No HP</label>
                                                                                            <input type="text" id="hp" name="hp" class="form-control">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-sm-3">
                                                                                            <label>No KTP</label>
                                                                                            <input type="text" id="no_ktp" name="no_ktp" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>Status Pernikahan</label>
                                                                                            <select class="form-control" id="status" name="status">
                                                                                                <option value="0">Pilih Status</option>
                                                                                                <option value="Belum Menikah">Belum Menikah</option>
                                                                                                <option value="Menikah">Menikah</option>
                                                                                                <option value="Janda">Janda</option>
                                                                                                <option value="Duda">Duda</option>                                                                
                                                                                            </select>
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>Nama Suami/Istri</label>
                                                                                            <input type="text" id="pasangan" name="pasangan" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>Jumlah Anak</label>
                                                                                            <input type="number" id="anak" name="anak" class="form-control">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-sm-4">
                                                                                            <label>Pendidikan Terakhir</label>
                                                                                            <select class="form-control" id="pendidikan" name="pendidikan">
                                                                                                <option>Pilih Pendidikan Terakhir</option>
                                                                                                <option value="SD">SD</option>
                                                                                                <option value="SMP">SMP</option>
                                                                                                <option value="SMA">SMA</option>
                                                                                                <option value="SMK">SMK</option>
                                                                                                <option value="D1">D1</option>
                                                                                                <option value="D2">D2</option>
                                                                                                <option value="D3">D3</option>
                                                                                                <option value="D4">D4</option>
                                                                                                <option value="S1">S1</option>
                                                                                                <option value="S2">S2</option>
                                                                                                <option value="S3">S3</option>
                                                                                            </select>
                                                                                        </div>
                                                                                        <div class="col-sm-4">
                                                                                            <label>Email</label>
                                                                                            <input type="email" id="email" name="email" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-4">
                                                                                            <label>No Telp Keluarga</label>
                                                                                            <input type="text" name="telp" id="telp" class="form-control">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-sm-8">
                                                                                            <label>Alamat</label>
                                                                                            <textarea class="form-control" id="alamat" name="alamat"></textarea>
                                                                                        </div>
                                                                                        <div class="col-sm-4">
                                                                                            <label>Tanggal Masuk</label>
                                                                                            <input type="date" id="tgl_masuk" name="tgl_masuk" class="form-control">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">

                                                                                        <div class="col-sm-3">
                                                                                            <label>Status Pegawai</label>
                                                                                            <select name="status_peg" id="status_peg" class="form-control">
                                                                                                <option>Pilih Status</option>
                                                                                                <option value="KONTRAK">Kontrak</option>
                                                                                                <option value="TETAP">Tetap</option>
                                                                                            </select>
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>Bagian</label>
                                                                                            <input type="text" id="bagian" name="bagian" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>Posisi</label>
                                                                                            <input type="text" id="posisi" name="posisi" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-3">
                                                                                            <label>Seksi</label>
                                                                                            <input type="text" id="seksi" name="seksi" class="form-control">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-sm-4">
                                                                                            <label>Nomor Kontrak 1</label>
                                                                                            <input type="text" name="no_k1" id="no_k1" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-4">
                                                                                            <label>Awal Masa Kontrak 1</label>
                                                                                            <input type="date" name="k1_awal" id="k1_awal" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-4">
                                                                                            <label>Akhir Masa Kontrak 1</label>
                                                                                            <input type="date" name="k1_akhir" id="k1_akhir" class="form-control">
                                                                                        </div>
                                                                                    </div>
                                                                                    <div class="row">
                                                                                        <div class="col-sm-4">
                                                                                            <label>Nomor Kontrak 2</label>
                                                                                            <input type="text" name="no_k2" id="no_k2" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-4">
                                                                                            <label>Awal Masa Kontrak 2</label>
                                                                                            <input type="date" name="k2_awal" id="k2_awal" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-4">
                                                                                            <label>Akhir Masa Kontrak 2</label>
                                                                                            <input type="date" name="k2_akhir" id="k2_akhir" class="form-control">
                                                                                        </div>
                                                                                    </div>
                                                                                    <!-- <div class="row">
                                                                                        <div class="col-sm-6">
                                                                                            <label>No. BPJS/KIS</label>
                                                                                            <input type="text" id="no_bpjs_kis" name="no_bpjs_kis" class="form-control">
                                                                                        </div>
                                                                                        <div class="col-sm-6">
                                                                                            <label>No. BPJS Ketenagakerjaan</label>
                                                                                            <input type="text" id="no_bpjs_kerja" name="no_bpjs_kerja" class="form-control">
                                                                                        </div>
                                                                                    </div> -->
                                                                                </div> 
                                                                            </div>
                                                                            <div class="modal-footer">
                                                                                <button type="submit" id="tombol" class="btn btn-outline-primary">Update Data Karyawan</button>
                                                                                <button type="button" class="btn btn-outline-warning" data-dismiss="modal">Cancel</button>
                                                                            </div>
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <!-- end modal scroll -->
                                                            <!-- Jquery JS-->
                                                            <script src="/vendor/jquery-3.2.1.min.js"></script>
                                                            <!-- Bootstrap JS-->
                                                            <script src="/vendor/bootstrap-4.1/popper.min.js"></script>
                                                            <script src="/vendor/bootstrap-4.1/bootstrap.min.js"></script>
                                                            <!-- Vendor JS       -->
                                                            <script src="/vendor/slick/slick.min.js">
                                                            </script>
                                                            <script src="/vendor/wow/wow.min.js"></script>
                                                            <script src="/vendor/animsition/animsition.min.js"></script>
                                                            <script src="/vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
                                                            </script>
                                                            <script src="/vendor/counter-up/jquery.waypoints.min.js"></script>
                                                            <script src="/vendor/counter-up/jquery.counterup.min.js">
                                                            </script>
                                                            <script src="/vendor/circle-progress/circle-progress.min.js"></script>
                                                            <script src="/vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
                                                            <script src="/vendor/chartjs/Chart.bundle.min.js"></script>
                                                            <script src="/vendor/select2/select2.min.js">
                                                            </script>
                                                            <script src="/js/dataTables.bootstrap4.min.js"></script>
                                                            <script src="/js/jquery.dataTables.min.js"></script>
                                                            <script src="/js/dataTables.bootstrap4.min.js"></script>
                                                            <script type="text/javascript">
                                                                $(document).ready(function() {
                                                                    $('#karyawan').DataTable();
                                                                } );
                                                            </script>
                                                            <!-- Main JS-->
                                                            <script src="/js/main.js"></script>

                                                        </body>

                                                        </html><?php /**PATH D:\laravel\sim_msi\resources\views/admin/karyawan.blade.php ENDPATH**/ ?>