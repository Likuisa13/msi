<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<h2>Uji Coba</h2>
<?php echo e($karyawan ->$nama_karyawan); ?>

</body>
</html><?php /**PATH D:\laravel\sim_msi\resources\views/admin/tes.blade.php ENDPATH**/ ?>