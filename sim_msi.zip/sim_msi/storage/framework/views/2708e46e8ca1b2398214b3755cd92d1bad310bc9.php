<!DOCTYPE html>
<html>
<head>
	<title>Cetak Data BPJS</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<!-- <link rel="stylesheet" href="/css/dataTables.bootstrap4.min.css"> -->
	<!-- <link href="/css/bootstrap.min.css" rel="stylesheet" media="all"> -->
	<!-- <link href=" <?php echo e(asset ('/css/bootstrap.min.css')); ?> "rel="stylesheet"> -->
	<!-- <link rel="stylesheet" type="text/css" href="/css/bootstrap.min.css" > -->
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h2>Data BPJS Karyawan</h2></center><br>
		<table class="table table-bordered">
			<thead>
				<tr>
					<td>No</td>
					<td><center>Nama</center></td>
					<td><center>ID</center></td>
					<td><center>No BPJS Kes/KIS</center></td>
					<td><center>Status BPJS</center></td>
					<td><center>No BPJS Ket</center></td>
				</tr>
			</thead>
			<tbody>
				<?php $i=1 ?>
				<?php $__currentLoopData = $bpjs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($b->status_bpjs =="Perusahaan"): ?>         
					<tr bgcolor="#00FFFF">         
				<?php else: ?>
					<tr>
				<?php endif; ?>
						<td><?php echo e($i++); ?></td>
						<td><?php echo e($b->nama_karyawan); ?></td>
						<td><?php echo e($b->id_karyawan); ?></td>
						<td><?php echo e($b->no_bpjs_kis); ?></td>
						<td><?php echo e($b->status_bpjs); ?></td>
						<td><?php echo e($b->no_bpjs_ket); ?></td>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>

		</body>
		</html><?php /**PATH D:\laravel\sim_msi\resources\views/admin/bpjs_pdf.blade.php ENDPATH**/ ?>