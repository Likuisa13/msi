<?php
   
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
 
// Route::get('/', function () {
//     return view('login'); 
// });
Route::get('/login','LoginController@index')->name('login');
Route::post('/login','LoginController@login')->name('login');
Route::get('/logout','LoginController@logout');
//route dashboard
Route::get('/admin/home','HomeController@index')->name('home');

//route karyawan
Route::get('/admin/karyawan/{status}', 'KaryawanController@show');
Route::get('/admin/karyawan-add', 'KaryawanController@add')->name('addkary');
Route::post('/admin/karyawan-save', 'KaryawanController@save')->name('savekary');
Route::post('/admin/karyawan-del', 'KaryawanController@del');
Route::post('/admin/karyawan-update', 'KaryawanController@update');
Route::get('/admin/karyawan-mutasi', 'KaryawanController@mutasi');
Route::get('/admin/xkary', 'KaryawanController@export')->name('export-karyawan');
Route::post('/admin/imkary', 'KaryawanController@storeData');
Route::get('/admin/print-kary', 'KaryawanController@cetak')->name('print-kary');

//route BPJS
Route::get('/admin/bpjs', 'BpjsController@show')->name('bpjs');
Route::post('/admin/bpjs-aksi', 'BpjsController@aksibpjs')->name('aksibpjs');
Route::post('/admin/bpjs-del', 'BpjsController@del');
Route::get('/admin/xbpjs', 'BpjsController@export')->name('export-bpjs');
Route::post('/admin/imbpjs', 'BpjsController@storeData');
Route::get('/admin/print-bpjs', 'BpjsController@cetak')->name('print-bpjs');

//route mutasi
Route::get('/admin/mutasi', 'MutasiController@show')->name('mutasi');
Route::post('/admin/mutasi-aksi', 'MutasiController@aksi')->name('aksimutasi');
Route::post('/admin/mutasi-del', 'MutasiController@del');
Route::get('/admin/xmutasi', 'MutasiController@export')->name('export-mutasi');
Route::post('/admin/imutasi', 'MutasiController@storeData');
Route::get('/admin/print-mutasi', 'MutasiController@cetak')->name('print-mutasi');

//route resign
Route::get('/admin/resign', 'ResignController@show')->name('resign');
Route::post('/admin/resign-aksi', 'ResignController@aksi')->name('aksiresign');
Route::post('/admin/resign-del', 'ResignController@del');
Route::get('/admin/xresign', 'ResignController@export')->name('export-resign');
Route::post('/admin/iresign', 'ResignController@storeData');
Route::get('/admin/print-resign', 'ResignController@cetak')->name('print-resign');

//route obat/stok
Route::get('/admin/obat', 'ObatController@show')->name('obat');
Route::post('/admin/obat-aksi', 'ObatController@aksi')->name('aksiobat');
Route::post('/admin/obat-del', 'ObatController@del');
Route::get('/admin/xobat', 'ObatController@export')->name('export-obat');
Route::post('/admin/iobat', 'ObatController@storeData');

//route obat masuk
Route::get('/admin/obat/masuk', 'ObatController@showMasuk')->name('obatMasuk');
Route::post('/admin/obat/masuk-aksi', 'ObatController@aksiMasuk')->name('aksiobatMasuk');
Route::post('/admin/obat/masuk-del', 'ObatController@delMasuk');
Route::post('/admin/xobat/masuk', 'ObatController@exportMasuk')->name('export-obatMasuk');
Route::post('/admin/iobat/masuk', 'ObatController@storeDataMasuk');

//route obat keluar
Route::get('/admin/obat/keluar', 'ObatController@showKeluar')->name('obatKeluar');
Route::post('/admin/obat/keluar-aksi', 'ObatController@aksiKeluar')->name('aksiobatKeluar');
Route::post('/admin/obat/keluar-del', 'ObatController@delKeluar');
Route::post('/admin/xobat/keluar', 'ObatController@exportKeluar')->name('export-obatKeluar');
Route::post('/admin/iobat/keluar', 'ObatController@storeDataKeluar');

//route kecelakaan
Route::get('/admin/k3', 'K3Controller@show')->name('k3');
Route::post('/admin/k3-aksi', 'K3Controller@aksi')->name('aksik3');
Route::post('/admin/k3-del', 'K3Controller@del');
Route::post('/admin/xk3', 'K3Controller@export')->name('export-k3');
Route::post('/admin/ik3', 'K3Controller@storeData');
 
//route ajax
Route::post('/admin/cek', 'KaryawanController@cek')->name('cekId');
Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
